from __future__ import print_function
from __future__ import division
import data_extraction
import xlrd
import os
import shutil
from pyomo.opt import SolverFactory, SolverManagerFactory
import math
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
#import pyomo.core as pyo
import pyomo.environ as pyo
import warnings
from datetime import datetime
from operator import itemgetter
from random import random

# -----------------------------------------------------------------------------#
## Organization of the code :
# Creation of the model
# Global parameters definition
# Sets definition
# Parameters definition
# Variables definition
# Constraints definition
# Objective function creation
# Resolution of the model with instance creation
#
# Some lines must be changed because they contain paths : l34, 544, 565.
# -----------------------------------------------------------------------------#

# excel path for recovery of demand and ambient temperature
excel_path = 'C:/Users/agnes.francois/Case_study/data.xlsx'

# model creation
model = pyo.AbstractModel()
model.name = 'TEST1'

model.created = datetime.now().strftime('%Y%m%dT%H%M')

# -----------------------------------------------------------------------------#
## Global parameters ##
# -----------------------------------------------------------------------------#
# number of hours, technologies, timesteps (from the Excel "Global" sheet)
model.hours = pyo.Param(within=pyo.NonNegativeIntegers)
model.unique_conv = pyo.Param(within=pyo.NonNegativeIntegers)
model.conv = pyo.Param(within=pyo.NonNegativeIntegers)
model.unique_stor = pyo.Param(within=pyo.NonNegativeIntegers)
model.stor = pyo.Param(within=pyo.NonNegativeIntegers)
model.techs = pyo.Param(within=pyo.NonNegativeIntegers)
model.inputs = pyo.Param(within=pyo.NonNegativeIntegers)
model.demand = pyo.Param(within=pyo.NonNegativeIntegers)

# -----------------------------------------------------------------------------#
## Sets ##
# -----------------------------------------------------------------------------#
# sets are lists of things, elements that compose the model
model.Time = pyo.RangeSet(1, model.hours)
model.SubTime = pyo.RangeSet(2, model.hours)  # used for storage
model.UConv = pyo.Set()  # CHP, HP
model.Conv = pyo.Set()  # CHP(1-2-3), HP(1-2-3)
model.UStor = pyo.Set()  # Battery, Hot water
model.Stor = pyo.Set()  # Battery(1-2-3), Hot water(1-2-3)
model.Techs = pyo.Set()  # CHP(1-2-3), HP(1-2-3), Battery(1-2-3), Hot water(1-2-3)
model.In = pyo.Set()  # Electricity grid, natural gas
model.InCategory = pyo.Set()  # electricity, fuel
model.Out = pyo.Set()  # electricity, space heat, domestic hot water
model.OutCategory = pyo.Set(initialize=["elec", "heat"])
model.Heat = pyo.Set(initialize=["dhw", "sh"])

def conv_HP(model):
    return (x for x in model.Conv if "Heat_Pump" in x)

def conv_CHP(model):
    return (x for x in model.Conv if "CHP" in x)

def stor_battery(model):
    return(x for x in model.Stor if "Battery" in x)

def stor_HW(model):
    return(x for x in model.Stor if "Hot_water" in x)


model.HP = pyo.Set(initialize=conv_HP)  # HP(1-2-3)
model.CHP = pyo.Set(initialize=conv_CHP)  # CHP(1-2-3)
model.Battery = pyo.Set(initialize=stor_battery)  # Battery(1-2-3)
model.HW = pyo.Set(initialize=stor_HW)  # Hot water(1-2-3)

model.ElecIn = pyo.Set()  # HP(1-2-3), Battery(1-2-3)
model.ElecOut = pyo.Set()  # Battery(1-2-3)
model.FuelIn = pyo.Set()  # CHP(1-2-3)
model.HeatIn = pyo.Set()  # Hot water(1-2-3)
model.HeatOut = pyo.Set()  # HP(1-2-3), Hot water(1-2-3)
model.Fuels = pyo.Set()  # Natural gas
model.Elec = pyo.Set()  # Electricity grid

# -----------------------------------------------------------------------------#
## Parameters ## (all from the Excel)
# -----------------------------------------------------------------------------#
# Inputs
model.ICategory = pyo.Param(model.In, domain=pyo.Any)
model.IMin_capacity = pyo.Param(model.In, domain=pyo.NonNegativeReals)
model.IMax_capacity = pyo.Param(model.In, domain=pyo.NonNegativeReals)
model.Iho = pyo.Param(model.In, domain=pyo.NonNegativeReals)
model.Ihu = pyo.Param(model.In, domain=pyo.NonNegativeReals)
model.Icostw = pyo.Param(model.In, domain=pyo.NonNegativeReals)
model.IFeedIn = pyo.Param(model.In, domain=pyo.NonNegativeReals)
model.Icostkg = pyo.Param(model.In, domain=pyo.NonNegativeReals)
model.Ipenr = pyo.Param(model.In, domain=pyo.Reals)
model.Iper = pyo.Param(model.In, domain=pyo.Reals)
model.IGWP100 = pyo.Param(model.In, domain=pyo.Reals)

# Converters
model.CMin_capacity = pyo.Param(model.Conv, domain=pyo.NonNegativeReals)
model.CMax_capacity = pyo.Param(model.Conv, domain=pyo.NonNegativeReals)
model.CSwitching_frequency = pyo.Param(model.Conv, domain=pyo.NonNegativeReals)
model.CNumber_max_per_building = pyo.Param(model.Conv, domain=pyo.Integers)
model.CInput = pyo.Param(model.Conv, domain=pyo.Any)
model.COutput = pyo.Param(model.Conv, domain=pyo.Any)
model.CMaintenanceCost = pyo.Param(model.Conv, domain=pyo.NonNegativeReals)
model.CInstallationCost = pyo.Param(model.Conv, domain=pyo.NonNegativeReals)
model.CPlanificationCost = pyo.Param(model.Conv, domain=pyo.NonNegativeReals)
model.CInvestmentCost = pyo.Param(model.Conv, domain=pyo.NonNegativeReals)
model.CInvestmentCostBase = pyo.Param(model.Conv, domain=pyo.NonNegativeReals)

# Storage
model.SMin_capacity = pyo.Param(model.Stor, domain=pyo.NonNegativeReals)
model.SMax_capacity = pyo.Param(model.Stor, domain=pyo.NonNegativeReals)
model.SNumber_max_per_building = pyo.Param(model.Stor, domain=pyo.Integers)
model.SMin_power_of_charging = pyo.Param(model.Stor, domain=pyo.NonNegativeReals)
model.SMax_power_of_charging = pyo.Param(model.Stor, domain=pyo.NonNegativeReals)
model.SMin_power_of_discharging = pyo.Param(model.Stor, domain=pyo.NonNegativeReals)
model.SMax_power_of_discharging = pyo.Param(model.Stor, domain=pyo.NonNegativeReals)
model.SEfficiency_of_charging = pyo.Param(model.Stor, domain=pyo.NonNegativeReals)
model.SEfficiency_of_discharging = pyo.Param(model.Stor, domain=pyo.NonNegativeReals)
model.SInput = pyo.Param(model.Stor, domain=pyo.Any)
model.SOutput = pyo.Param(model.Stor, domain=pyo.Any)
model.SInstallationCost = pyo.Param(model.Stor, domain=pyo.NonNegativeReals)
model.SPlanificationCost = pyo.Param(model.Stor, domain=pyo.NonNegativeReals)
model.SInvestmentCost = pyo.Param(model.Stor, domain=pyo.NonNegativeReals)
model.SInvestmentCostBase = pyo.Param(model.Stor, domain=pyo.NonNegativeReals)

model.InitState = pyo.Param(initialize=0)

# Ambient temperature
Weather = pd.read_excel(excel_path, sheet_name="Weather", index_col=0, engine='openpyxl')
Tamb = {}

for i in range(1, Weather.shape[0]+1):
    Tamb[i] = Weather.iloc[i-1][0]
model.Tamb = pyo.Param(model.Time, initialize=Tamb)

# Demand
Demand = pd.read_excel(excel_path, sheet_name="Demand", index_col=0, engine='openpyxl')
elecDemand = {}
shDemand = {}
dhwDemand = {}

for i in range(1, Demand.shape[0]+1):
    elecDemand[i] = Demand.iloc[i-1][0]
    shDemand[i] = Demand.iloc[i-1][1]
    dhwDemand[i] = Demand.iloc[i-1][2]
model.elecDemand = pyo.Param(model.Time, initialize=elecDemand)
model.shDemand = pyo.Param(model.Time, initialize=shDemand)
model.dhwDemand = pyo.Param(model.Time, initialize=dhwDemand)


# -----------------------------------------------------------------------------#
## Variable ##
# -----------------------------------------------------------------------------#
# Inputs

def bound_tinp_rule(model, t, inp):
    return(model.IMin_capacity[inp], model.IMax_capacity[inp])


model.Tinp = pyo.Var(model.Time, model.In,
                     bounds=bound_tinp_rule, domain=pyo.NonNegativeReals,
                     doc='Quantity of input consumed per time')

model.ElecTech = pyo.Var(model.Time, model.ElecIn,
                         domain=pyo.NonNegativeReals,
                         doc='Quantity of electricity from the grid that goes into the corresponding technologies per time')

model.FuelTech = pyo.Var(model.Time, model.Fuels, model.FuelIn,
                         domain=pyo.NonNegativeReals,
                         doc='Quantity of fuels that goes into the corresponding technologies per time')

model.FeedIn = pyo.Var(model.Time, model.CHP,
                       domain=pyo.NonNegativeReals, initialize=0,
                       doc='Quantity of electricity produced by CHP that is sold to the grid')
# Technologies
model.TechCapacity = pyo.Var(model.Techs,
                             domain=pyo.NonNegativeReals,
                             doc='Capacity of each technology')

model.TechUse = pyo.Var(model.Techs,
                        domain=pyo.Binary,
                        doc='Binary describing the use of a technology during the whole horizon')

model.TechUset = pyo.Var(model.Time, model.Techs,
                         domain=pyo.Binary, initialize=0,
                         doc='Binary describing the use of a technology per timestep')

model.Switch = pyo.Var(model.Time, model.HP | model.CHP,
                       bounds=(-1, 1), domain=pyo.Integers, initialize=0,
                       doc='Integer describing the switching state of HP and CHP : -1, 0 or 1')

model.TechIn = pyo.Var(model.Time, model.Techs - model.HeatIn,
                       domain=pyo.NonNegativeReals, initialize=0,
                       doc='Quantity of power received by every technology (except heat-in) per time')

model.TechHeatInG = pyo.Var(model.Time, model.HeatIn, model.Heat,
                            domain=pyo.NonNegativeReals, initialize=0,
                            doc='Quantity of heat received by corresponding technologies per time')

model.TechOut = pyo.Var(model.Time, model.Techs - model.CHP - model.HeatOut,
                        domain=pyo.NonNegativeReals,
                        doc='Quantity of power out of every technology (except CHP and heat-out) per time')

model.TechHeatOutG = pyo.Var(model.Time, model.HeatOut, model.Heat,
                             domain=pyo.NonNegativeReals,
                             doc='Quantity of heat out of corresponding technologies per time')

model.TechCHPOut = pyo.Var(model.Time, model.CHP, model.Out,
                           domain=pyo.NonNegativeReals,
                           doc='Quantity of power out of CHP technologies per time')

model.SOC = pyo.Var(model.Time, model.Battery,
                    domain=pyo.NonNegativeReals, initialize=model.InitState,
                    doc='State of charge of the battery per time')

model.SOCdhw = pyo.Var(model.Time, model.HW,
                       domain=pyo.NonNegativeReals, initialize=model.InitState,
                       doc='State of charge of the HW DHW storage per time')

model.SOCsh = pyo.Var(model.Time, model.HW,
                      domain=pyo.NonNegativeReals, initialize=model.InitState,
                      doc='State of charge of the HW SH storage per time')


model.TechFlow = pyo.Var(model.Time, model.Techs, model.Techs, model.Out,
                         domain=pyo.NonNegativeReals, initialize=0)

# Demande
model.DemElec = pyo.Var(model.Time, model.Elec | model.ElecOut | model.CHP,
                        domain=pyo.NonNegativeReals,
                        doc='Quantity of electricity satisfying the demand per time and its origin')

model.DemSH = pyo.Var(model.Time, model.HeatOut | model.CHP,
                      domain=pyo.NonNegativeReals,
                      doc='Quantity of heat satisfying the demand of SH per time and its origin')

model.DemDHW = pyo.Var(model.Time, model.HeatOut | model.CHP,
                       domain=pyo.NonNegativeReals,
                       doc='Quantity of heat satisfying the demand of DHW per time and its origin')

# -----------------------------------------------------------------------------#
## Constraints ##
# -----------------------------------------------------------------------------#

# Demand
def demand_elec_rule(model, t):
    return sum(model.DemElec[t, x] for x in model.Elec | model.ElecOut | model.CHP) == model.elecDemand[t]

def demand_sh_rule(model, t):
    return sum(model.DemSH[t, x] for x in model.HeatOut | model.CHP) == model.shDemand[t]

def demand_dhw_rule(model, t):
    return sum(model.DemDHW[t, x] for x in model.HeatOut | model.CHP) == model.dhwDemand[t]


model.respect_elec_demand = pyo.Constraint(model.Time, rule=demand_elec_rule,
                                           doc='Satisfaction of electricity demand')
model.respect_sh_demand = pyo.Constraint(model.Time, rule=demand_sh_rule,
                                         doc='Satisfaction of SH demand')
model.respect_dhw_demand = pyo.Constraint(model.Time, rule=demand_dhw_rule,
                                          doc='Satisfaction of DHW demand')

# Definition of the outputs and inputs flows
def outputs_rule(model, t, tech, out):
    if tech in model.CHP:
        if out == "elec":
            return model.TechCHPOut[t, tech, out] == sum(model.TechFlow[t, tech, i, "elec"] for i in model.ElecIn) + model.FeedIn[t, tech] + model.DemElec[t, tech]
        elif out == "dhw":
            return model.TechCHPOut[t, tech, out] == sum(model.TechFlow[t, tech, i, out] for i in model.HeatIn) + model.DemDHW[t, tech]
        else:
            return model.TechCHPOut[t, tech, out] == sum(model.TechFlow[t, tech, i, out] for i in model.HeatIn) + model.DemSH[t, tech]
    elif tech in model.ElecOut:
        return model.TechOut[t, tech] == sum(model.TechFlow[t, tech, i, "elec"] for i in model.ElecIn) + model.DemElec[t, tech]
    elif tech in model.HeatOut:
        if out == "dhw":
            return model.TechHeatOutG[t, tech, out] == sum(model.TechFlow[t, tech, i, out] for i in model.HeatIn) + model.DemDHW[t, tech]
        elif out == "sh":
            return model.TechHeatOutG[t, tech, out] == sum(model.TechFlow[t, tech, i, out] for i in model.HeatIn) + model.DemSH[t, tech]
        else:
            return pyo.Constraint.Skip

def inputs_rule(model, t, tech, heat):
    if tech in model.ElecIn:
        return model.TechIn[t, tech] == sum(model.TechFlow[t, x, tech, "elec"] for x in model.ElecOut) + model.ElecTech[t, tech]
    elif tech in model.FuelIn:
        return model.TechIn[t, tech] == sum(model.FuelTech[t, x, tech] for x in model.Fuels)
    else:
        return model.TechHeatInG[t, tech, heat] == sum(model.TechFlow[t, x, tech, heat] for x in model.HeatOut | model.CHP)

def distribution_input_rule(model, t, input):
    if input in model.Elec:
        return model.Tinp[t, input] == sum(model.ElecTech[t, x] for x in model.ElecIn) + model.DemElec[t, input]
    elif input in model.Fuels:
        return model.Tinp[t, input] == sum(model.FuelTech[t, input, x] for x in model.FuelIn)

def constraint_flow(model, t, techa, techb, a):
    if techa == techb:
        return model.TechFlow[t, techa, techb, a] == 0
    else:
        return pyo.Constraint.Skip


model.respect_outputs = pyo.Constraint(model.Time, model.Techs, model.Out, rule=outputs_rule,
                                       doc='Definition of the outputs of a technology')

model.respect_inputs = pyo.Constraint(model.Time, model.Techs, model.Heat, rule=inputs_rule,
                                      doc='Definition of the input of a technology')

model.respect_distribution_input = pyo.Constraint(model.Time, model.In, rule=distribution_input_rule,
                                                  doc='Definition of the quantity of inputs used')

model.respect_constraint_flow = pyo.Constraint(model.Time, model.Techs, model.Techs, model.Out, rule=constraint_flow,
                                               doc='A technology cant use what it produces')

# Definition of the capacities

def min_tech_rule(model, tech):
    if tech in model.Conv:
        return model.TechCapacity[tech] >= model.CMin_capacity[tech] * model.TechUse[tech]
    elif tech in model.Stor:
        return model.TechCapacity[tech] >= model.SMin_capacity[tech] * model.TechUse[tech]

def max_tech_rule(model, tech):
    if tech in model.Conv:
        return model.TechCapacity[tech] <= model.CMax_capacity[tech] * model.TechUse[tech]
    elif tech in model.Stor:
        return model.TechCapacity[tech] <= model.SMax_capacity[tech] * model.TechUse[tech]


model.respect_min_tech = pyo.Constraint(model.Techs, rule=min_tech_rule,
                                        doc='Minimzation of the capacity of the technologies')

model.respect_max_tech = pyo.Constraint(model.Techs, rule=max_tech_rule,
                                        doc='Maximization of the capacity of the technologies')


def capacity_tech_rule(model, t, tech):
    if tech in model.CHP:
        return sum(model.TechCHPOut[t, tech, a] for a in model.Out) <= model.TechCapacity[tech]
    # elif tech in model.Battery:
    #     return model.SOC[t, tech] <= model.TechCapacity[tech]
    elif tech in model.HeatOut:
        return sum(model.TechHeatOutG[t, tech, a] for a in model.Heat) <= model.TechCapacity[tech]
    else:
        return model.TechOut[t, tech] <= model.TechCapacity[tech]

def capacity_hw_sh_rule(model, t, hw):
    return model.SOCsh[t, hw] <= model.TechCapacity[hw]/2

def capacity_hw_dhw_rule(model, t, hw):
    return model.SOCdhw[t, hw] <= model.TechCapacity[hw]/2


model.respect_capacity_tech = pyo.Constraint(model.Time, model.Techs, rule=capacity_tech_rule,
                                             doc='Maximization of the output of a technology with its capacity')
model.respect_capacity_hw_sh = pyo.Constraint(model.Time, model.HW, rule=capacity_hw_sh_rule,
                                              doc='Maximization of the SOC for SH in hot water storage')
model.respect_capacity_hw_dhw = pyo.Constraint(model.Time, model.HW, rule=capacity_hw_dhw_rule,
                                               doc='Maximization of the SOC for DHW in hot water storage')

# HP model
# the relation between the temperature of the condensor and of ambient temperature is from the EcoDynbat project
# every temperature must be in Celsius degrees
# ones will be modified when model parameters are defined
def hp_rule(model, t, hp):
    efficaciteqdhw = (3 + 3 * model.Tamb[t] + 3 * 55 + 3 * model.Tamb[t] * 55 + 3 * (model.Tamb[t] ^ 2) + 3 * 55)
    efficacitewdhw = (1 + 1 * model.Tamb[t] + 1 * 55 + 1 * model.Tamb[t] * 55 + 1 * (model.Tamb[t] ^ 2) + 1 * 55)
    COPdhw = efficaciteqdhw / efficacitewdhw
    Tcond = 25 * (model.Tamb[t] > 15) + (32.5 - 1 / 2 * model.Tamb[t]) * (model.Tamb[t] <= 15)
    efficaciteqsh = (3 + 3 * model.Tamb[t] + 3 * Tcond + 3 * model.Tamb[t] * Tcond + 3 * (model.Tamb[t] ^ 2) + 3 * Tcond)
    efficacitewsh = (1 + 1 * model.Tamb[t] + 1 * Tcond + 1 * model.Tamb[t] * Tcond + 1 * (model.Tamb[t] ^ 2) + 1 * Tcond)
    COPsh = efficaciteqsh / efficacitewsh
    return model.TechIn[t, hp] == model.TechHeatOutG[t, hp, "dhw"] * COPdhw + model.TechHeatOutG[t, hp, "sh"] * COPsh

# Priority of Domestic Hot Water over Space Heat
def hp_sh_rule(model, t, hp):
    return model.TechHeatOutG[t, hp, "sh"] <= model.TechCapacity[hp] - model.TechHeatOutG[t, hp, "dhw"]


model.respect_hp = pyo.Constraint(model.Time, model.HP, rule=hp_rule,
                                  doc='Efficiency definition of HP technologies')
model.respect_hp_sh = pyo.Constraint(model.Time, model.HP, rule=hp_sh_rule,
                                     doc='SH relation for HP model')

# CHP model
# model not yet defined
def chp_rule(model, t, chp, a):
    if a == "elec":
        return model.TechCHPOut[t, chp, a] == model.TechIn[t, chp] * 0.4
    else:
        return model.TechCHPOut[t, chp, a] == model.TechIn[t, chp] * 0.45

# Priority of Domestic Hot Water over Space Heat
def chp_sh_rule(model, t, chp):
    return model.TechCHPOut[t, chp, "sh"] <= model.TechCapacity[chp] - model.TechCHPOut[t, chp, "dhw"]


model.respect_chp = pyo.Constraint(model.Time, model.CHP, model.Out, rule=chp_rule,
                                   doc='Efficiency definition of CHP technologies')
model.respect_chp_sh = pyo.Constraint(model.Time, model.CHP, rule=chp_sh_rule,
                                      doc="SH relation for CHP model")

# Battery model
# model not yet defined
def SOC_battery_rule(model, t, batt):
    return model.SOC[t, batt] == model.SOC[t-1, batt] + model.TechIn[t-1, batt] * model.SEfficiency_of_charging[batt] - \
           model.TechOut[t-1, batt] / model.SEfficiency_of_discharging[batt]

def init_state_battery_rule(model, batt):
    return model.SOC[1, batt] == model.InitState

def final_state_battery_rule(model, batt):
    return model.SOC[model.hours, batt] == model.InitState


model.respect_SOC_battery = pyo.Constraint(model.SubTime, model.Battery, rule=SOC_battery_rule,
                                           doc='Definition of the state of charge of a battery')

model.respect_init_state_battery = pyo.Constraint(model.Battery, rule=init_state_battery_rule,
                                                  doc='Initial state to 0 for a battery (doesnt work with initializing the variable)')

model.respect_final_state_battery = pyo.Constraint(model.Battery, rule=final_state_battery_rule,
                                                   doc='Final state to 0 for a battery')

# Hot Water storage model
# model not yet defined
def SOC_HW_dhw_rule(model, t, hw):
    return model.SOCdhw[t, hw] == model.SOCdhw[t-1, hw] + model.TechHeatInG[t-1, hw, "dhw"] * model.SEfficiency_of_charging[hw] - \
           model.TechHeatOutG[t-1, hw, "dhw"] / model.SEfficiency_of_discharging[hw]

def SOC_HW_sh_rule(model, t, hw):
    return model.SOCsh[t, hw] == model.SOCsh[t-1, hw] + model.TechHeatInG[t-1, hw, "sh"] * model.SEfficiency_of_charging[hw] - \
           model.TechHeatOutG[t-1, hw, "sh"] / model.SEfficiency_of_discharging[hw]

def init_state_HW_dhw_rule(model, hw):
    return model.SOCdhw[1, hw] == model.InitState

def init_state_HW_sh_rule(model, hw):
    return model.SOCsh[1, hw] == model.InitState

def final_state_HW_dhw_rule(model, hw):
    return model.SOCdhw[model.hours, hw] == model.InitState

def final_state_HW_sh_rule(model, hw):
    return model.SOCsh[model.hours, hw] == model.InitState


model.respect_SOC_HW_dhw = pyo.Constraint(model.SubTime, model.HW, rule=SOC_HW_dhw_rule,
                                          doc='Definition of the state of charge of a Hot water storage, dhw part')

model.respect_SOC_HW_sh = pyo.Constraint(model.SubTime, model.HW, rule=SOC_HW_sh_rule,
                                         doc='Definition of the state of charge of a Hot water storage, sh part')

model.respect_init_state_HW_dhw = pyo.Constraint(model.HW, rule=init_state_HW_dhw_rule,
                                                 doc='Initial state to 0 for hot water storage (doesnt work with initializing the variable)')

model.respect_init_state_HW_sh = pyo.Constraint(model.HW, rule=init_state_HW_sh_rule,
                                                doc='Initial state to 0 for hot water storage (doesnt work with initializing the variable)')

model.respect_final_state_HW_dhw = pyo.Constraint(model.HW, rule=final_state_HW_dhw_rule,
                                                  doc='Final state to 0 for hot water storage')

model.respect_final_state_HW_sh = pyo.Constraint(model.HW, rule=final_state_HW_sh_rule,
                                                 doc='Final state to 0 for hot water storage')

# -----------------------------------------------------------------------------#
## Objectives ##
# -----------------------------------------------------------------------------#

model.fcosts = pyo.Var()
#model.femissions = pyo.Var()

def objective_costs(model):
    # Maintenance cost per year for HP model, per kWh for CHP model
    return model.fcosts == sum(model.Icostw[inp]*model.Tinp[time, inp] for inp in model.In for time in model.Time) + \
                            sum(model.CMaintenanceCost[tech] * (model.TechCapacity[tech]*model.CInvestmentCost[tech] + model.CInvestmentCostBase[tech]) for tech in model.Conv) + \
                            sum(model.CInstallationCost[tech] * (model.TechCapacity[tech] * model.CInvestmentCost[tech] + model.CInvestmentCostBase[tech]) for tech in model.Conv) + \
                            sum(model.CPlanificationCost[tech] * (model.TechCapacity[tech]*model.CInvestmentCost[tech] + model.CInvestmentCostBase[tech]) for tech in model.Conv) + \
                            sum(model.TechCapacity[tech]*model.CInvestmentCost[tech] + model.CInvestmentCostBase[tech] for tech in model.Conv) + \
                            sum(model.SInstallationCost[tech] * (model.TechCapacity[tech] * model.SInvestmentCost[tech] + model.SInvestmentCostBase[tech]) for tech in model.Stor) + \
                            sum(model.SPlanificationCost[tech] * (model.TechCapacity[tech] * model.SInvestmentCost[tech] + model.SInvestmentCostBase[tech]) for tech in model.Stor) + \
                            sum(model.TechCapacity[tech] * model.SInvestmentCost[tech] + model.SInvestmentCostBase[tech] for tech in model.Stor) + \
                            -model.IFeedIn["Electricity_grid"] * sum(model.FeedIn[t, tech] for t in model.Time for tech in model.CHP)


#def objective_emissions(model):
#    return model.femissions == sum(model.Emissions[Tech]*model.Power[Tech, Time] for Tech in model.Tech for Time in model.Time)


model.C_fcosts = pyo.Constraint(rule=objective_costs)
#model.C_femissions = pyo.Constraint(rule=objective_emissions)
model.O_fcosts = pyo.Objective(expr=model.fcosts, sense=pyo.minimize)
#model.O_femissions = pyo.Objective(expr=model.femissions, sense=minimize)

## Multi-optimization

# model.O_femissions.deactivate()
#
# solver = SolverFactory('gurobi')
# solver.solve(model);
#
# #print( '( X1 , X2 ) = ( ' + str(value(model.X1)) + ' , ' + str(value(model.X2)) + ' )')
# #print( 'f1 = ' + str(value(model.f1)) )
# #print( 'f2 = ' + str(value(model.f2)) )
# femissions_max = value(model.femissions)
#
#
# # ## max f2
#
# model.O_femissions.activate()
# model.O_fcosts.deactivate()
#
# solver = SolverFactory('gurobi')
# solver.solve(model);
#
# #print( '( X1 , X2 ) = ( ' + str(value(model.X1)) + ' , ' + str(value(model.X2)) + ' )')
# #print( 'f1 = ' + str(value(model.f1)) )
# #print( 'f2 = ' + str(value(model.f2)) )
# femissions_min = value(model.femissions)

# -----------------------------------------------------------------------------#
## Print model ##
# -----------------------------------------------------------------------------#

# create an instance of the model depending on the data in the file 'extraction.dat'
result_path = 'C:/Users/agnes.francois/Case_study/extraction.dat'
data_extraction.extraction(excel_path, result_path)

instance = model.create_instance('extraction.dat')
#instance.pprint()  # print every set, parameter, variable and constraint created


# select the MILP solver
opt = SolverFactory("gurobi")  # slover can be chosen here
opt.options["mipgap"] = 0.001  # define optimality gap
opt.Tee = True

solver_manager = SolverManagerFactory("serial")  # solve instances in series
results = solver_manager.solve(instance, tee=True, opt=opt, timelimit=None)

instance.solutions.store_to(results)
#instance.FeedIn.pprint()
#instance.SOCdhw.pprint()

# Method to save optimisation results to txt file
def pyomo_save_results(resultats):
    OUTPUT = open('C:/Users/agnes.francois/Case_study/ResultsTEST1.txt', 'w')
    print(resultats, file=OUTPUT)
    OUTPUT.close()


pyomo_save_results(resultats=results)    # to activate in order to save the results in txt file

#Example of how to print variables
#print("TOTAL COST")
#print(instance.TotalCost.value)
